# Misty CLI

Experimental command line interface for Misty. Works on Windows, OS X, and Linux.

Requires that Misty be connected via WiFi to the same network as the user running the CLI. The CLI uses the REST API to call the robot to do things.

Looking for the latest pre-built binaries? Go to https://github.com/MistyPioneers/Woz1/releases

## How to use

        ./misty
        Usage:
            misty [command]

        Available Commands:
            arm         Move the robot arm
            eyes        Set eyes to a specific expression
            head        Move the robot head
            help        Help about any command
            led         Set LED color
            map         Control SLAM mapping system
            move        Move the robot
            pause       Pause the robot movement
            say         Say something
            sensors     Show sensor readings
            sound       Play and list avilable sounds
            tracking    Control SLAM tracking system

        Flags:
            -d, --debug           show debug output
            -h, --help            help for misty
            -i, --ipaddr string   ip addr for robot

        Use "misty [command] --help" for more information about a command.

### Configuration

You can also set the `MISTY_IP` environment variable, so you do not have to keep entering it in as a flag to every command.

#### Windows

        set MISTY_IP=192.168.1.51

#### OS X/Linux

        export MISTY_IP=192.168.1.51

## How to build

If you need to build from source, you must have installed Go. You can cross-compile a standalone binary of the Misty CLI for each platform from any computer, by using the following commands.

### Windows

        GOOS=windows GOARCH=x86 go build -o misty.exe main.go

### OS X

        GOOS=darwin GOARCH=x86 go build -o misty main.go

### Linuxs

        GOOS=linux GOARCH=x86 go build -o misty main.go


Users do not need to have installed Go to use the standalone binary CLI built by the above command.
