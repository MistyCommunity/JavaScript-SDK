import json
from twilio.rest import Client

def lambda_handler(event, context):
    # TODO implement
    account_sid = "<your_accouny_id>"
    auth_token  = "<your_auth_token>"
    
    client = Client(account_sid,auth_token)
    
    message = client.messages.create(
        to="<your_mobile_number>",
        from_="<your_twilio_phone_number> ",
        body="Misty Security: An intruder is at your desk <your_name>. Should I call the cops?")
    
    print(message.sid)
    return {
        'statusCode': 200,
        'body': json.dumps('Message Sent to <your_name>!')
    }
